<!DOCTYPE html>
<html>
    <head>
        <title>Fun Names</title>
        <style>
            p::first-letter {
                font-weight: bold;
            }
        </style>
    </head>
    <body>
    <?php 
                $words = array(
                    "A" => "Apple",
                    "B" => "Batman", 
                    "C" => "Cat",
                    "D" => "Dolittle", 
                    "E" => "Elephant In The Room", 
                    "F" => "Froyo",
                    "G" => "Gatorade",
                    "H" => "Harrison Wells", 
                    "I" => "Ireland",
                    "J" => "Jackman",  
                    "K" => "Kyle",
                    "L" => "Laundry", 
                    "M" => "Mrs. Norris",
                    "N" => "Nordic", 
                    "O" => "Opera", 
                    "P" => "Pakistan", 
                    "Q" => "Qurriel",
                    "R" => "Rosmerry", 
                    "S" => "Solid",
                    "T" => "Treasure", 
                    "U" => "Umbrella",
                    "V" => "Van",
                    "W" => "Window",
                    "X" => "X-men", 
                    "Y" => "Yodel",
                    "Z" => "Zebra"
                );
                $name = "Robert";
                // split the string into an array 
                $chars = str_split($name);
                // loop through each character in the array 
                foreach ($chars as $char) {
                    foreach ($words as $alpha => $word) {
                        if (strtolower($char) === strtolower($alpha)) {
                            echo "<p>".$word."<p>";
                        }
                    }
                }
            ?>
    </body>
</html>