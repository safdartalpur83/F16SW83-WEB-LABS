<!DOCTYPE html>
<html>
    <head>
        <!-- Write a PHP script to print "First", "White", and 2 from the following multi-dimensional array -->
        <title>Multidimensional Arrays</title>
    </head>
    <body>
        <?php 
            $color = array("color" => array("a" => "Red", "b" => "Green", "c" => "White"),
            "numbers" => array(1, 2, 3, 4, 5, 6), "holes" => array("First", 5 => "Second", "Third"));
            echo $color["holes"][0]." ".$color["color"]["c"]." ".$color["numbers"][1];
        ?>
    </body>
</html>